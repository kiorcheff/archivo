`1.6.0`
-------

- Required Color Option


`1.5.0`
-------

- Mobile Pager Pages

`1.4.0`
-------

- Background Blend Mode

`1.3.0`
-------

- Default Preferences

`1.2.0`
-------

- Added Menu Color Options

`1.2.0`
-------

- Added AppBar Color Options

`1.1.0`
-------

- Added Color Customize Options

`1.0.0`
-------

- Init version
